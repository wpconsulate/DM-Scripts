<?php
$_width = '600px';
?>
    
<table width="100%" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;" ondragstart="return false" onselectstart="return false">
<tr>
<td>

<!-- START outer table (wrap) -->
<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%">
<tr><td style="background: #e9e9e9;" align="center" valign="top">


<!-- START logo -->
<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #e9e9e9;" width="<?php echo $_width?>" height="24"></td></tr>
</table>
<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #e9e9e9;" width="183" height="44"><img style="width:100px;" src="{LOGO}" alt="" /></td>
<!-- END logo -->


<!-- START date -->
<td style="background: #e9e9e9;" width="417" height="44" align="right">
<div style="color: #717171; font-family: arial, verdana; font-size: 12px;"><b>{DATE}</b></div>
</td></tr>
</table>
<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #d1d1d1;" width="<?php echo $_width?>" height="22"><img src="{IMAGE_PATH}/header_top.jpg" /></td></tr>
</table>
<!-- END date -->


<!-- START image header -->
<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #d1d1d1;" width="<?php echo $_width?>" height="250"><img style="display: block;" src="{IMAGE_PATH}/banner.jpg" alt="" /></td></tr>
</table>
<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #e9e9e9;" width="<?php echo $_width?>" height="27"><img style="display: block;" src="{IMAGE_PATH}/image_header_shadow.jpg" /></td></tr>
</table>
<!-- END image header -->


<!-- START intro content -->
<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #f5f5f5;" width="24"></td>
<td style="background: #f5f5f5; color: #393939; font-family: arial, verdana; font-size: 25px;" width="552" align="left">
{TITLE}
</td>
<td style="background: #f5f5f5;" width="24"></td></tr>
</table>
<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #f5f5f5;" width="<?php echo $_width?>" height="15"></td></tr>
</table>
<table style="background: #f5f5f5;" cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #f5f5f5;" width="24"></td>
<td style="background: #f5f5f5; color: #707070; font-family: arial, verdana; font-size: 15px;" width="552" align="left">
{MESSAGE}
</td>
<td style="background: #f5f5f5;" width="24"></td></tr>
</table>
<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #f5f5f5;" width="<?php echo $_width?>" height="37"></td></tr>
</table>
<!-- END intro content -->


<!-- START footer -->
<table cellpadding="0" cellspacing="0" border="0">
<tr><td width="<?php echo $_width?>" height="8"><img src="{IMAGE_PATH}/top_footer.jpg" /></td></tr>
</table>
<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #d1d1d1;" width="<?php echo $_width?>" height="6"></td></tr>
</table>
<!--<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #d1d1d1;" width="27" height="37"></td>
<td style="background: #d1d1d1;" width="132" height="37"><img src="{IMAGE_PATH}/footer_logo.jpg" /></td>
<td style="background: #d1d1d1;" width="292" height="37"></td>
<td style="background: #d1d1d1;" width="30" height="30"><a href="#"><img border="0" src="{IMAGE_PATH}/icons/facebook.jpg" /></a></td>
<td style="background: #d1d1d1;" width="13" height="30"></td>
<td style="background: #d1d1d1;" width="30" height="30"><a href="#"><img border="0" src="{IMAGE_PATH}/icons/twitter.jpg" /></a></td> 
<td style="background: #d1d1d1;" width="13" height="30"></td>
<td style="background: #d1d1d1;" width="30" height="30"><a href="#"><img border="0" src="{IMAGE_PATH}/icons/rss.jpg" /></a></td> 
<td style="background: #d1d1d1;" width="33" height="30"></td></tr>
</table>-->
<table cellpadding="0" cellspacing="0" border="0">
<tr><td><img src="{IMAGE_PATH}/footer_bottom.jpg" /></td></tr>
</table>
<!--<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #e9e9e9; font-family: arial, verdana; font-size: 12px; color: #959595;" width="<?php echo $_width?>" align="center">You are receiving this email because you have signed up to our mailing list. If you do not want to <br/> receive our updates anymore you can <u><a style="color: #1f8fee; text-decoration: none;" href="#">unsubscribe</a></u> from our list.</td></tr>
</table>-->
<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="background: #e9e9e9;" width="<?php echo $_width?>" height="10"></td></tr>
</table>
<!-- END footer -->


</td></tr></table>
<!-- END outer table (wrap) -->

</td></tr>                        
</table>